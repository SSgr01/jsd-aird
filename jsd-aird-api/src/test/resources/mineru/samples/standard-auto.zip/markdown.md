Article

# Influence of an Alkoxylation Grade of Acrylates on Shrinkage of UV-Curable Compositions

**Zbigniew Czech** <strong><sup>1</sup></strong>**,\* , Janina Kabatc** <strong><sup>2</sup></strong>**,\* , Marcin Bartkowiak** <strong><sup>1</sup></strong>**, Karolina Mozelewska** <strong><sup>1</sup></strong> **and Dominika Kwiatkowska** <strong><sup>2</sup></strong>

1 International Laboratory of Adhesives and Self-Adhesive Materials, Department of Chemical Organic Technology and Polymeric Materials, Faculty of Chemical Technology and Engineering, West Pomeranian University of Technology, Pułaskiego 10, 70-322 Szczecin, Poland; marcin.bartkowiak@zut.edu.pl (M.B.); karolina\_mozelewska@zut.edu.pl (K.M.)

2 Department of Organic Chemistry, Faculty of Chemical Technology and Engineering, UTP University of Science and Technology, Seminaryjna 3, 85-326 Bydgoszcz, Poland; dominika.kwiatkowska@utp.edu.pl \* Correspondence: psa\_czech@wp.pl (Z.C.); nina@utp.edu.pl (J.K.)

Received: 9 October 2020; Accepted: 4 November 2020; Published: 6 November 2020

![](images/page_0_image_8.jpg)

**Abstract:** Commercially available UV curable restorative materials are composed of inorganic filler hydroxyapatite, multifunctional methacrylate, photoinitiator and alkoxylated acrylate. Especially, the application of alkoxylated monomers with different alkoxylation grade allows the reduction of polymerization shrinkage which plays the major role by application of low shrinkage composites as high quality restorative dental materials or other adhesive materials in the form of UV-polymerized self-adhesive acrylics layers (films). There are several ways to reduce polymerization shrinkage of restorative compositions, for example, by adjusting different alkoxylated acrylic monomers, which are integral part of investigated UV curable restorative composites. This article is focused on the studies of contraction-stress measured as shrinkage during UV-initiated curing of restorative composites containing various commercially available alkoxylated acrylates. Moreover, studies with experimental restorative materials and recent developments typical for UV curing technology using special photoreactive monomers are described.

**Keywords:** multifunctional alkoxylated acrylates; polymerization; shrinkage; restorative materials

## 1. Introduction

Polymerization shrinkage is still a technological problem of dental restorative composites. Polymerization shrinkage of UV curable composites is often caused by marginal and interphase defects of bonded components. The value of shrinkage phenomenon depends on the kind of applied composites: art and content of inorganic filler, and art of polymeric matrix containing multifunctional acrylates and methacrylates, radical photoinitiators and photoreactive polymeric fillers.

Dimethacrylate- or diacrylate-monomers have been applied in restorative compositions since the 1980s. Progress in filler technology, initiators systems and light sources has distinctly improved composite physical properties and extended its restorative applications [1,2]. Regardless, since early composites, the volumetric shrinkage resulting from conversion of applied dimethacrylate or methacrylate monomers into long, crosslinked polymer chains have been considered as a critical limitation that should be addressed [3,4]. The restorative composition polymerization shrinkage ranges from 2 to 6% by volume [5].

Moreover, it is well known that the modality by that light energy is used for photocuring of material influences on degree of conversion and mechanical properties of dental composites. Therefore, the properties of such materials may be “created” by using the appropriate light energy for photocuring process.

Soft light energy starts photopolymerization. The reduction of shrinkage stress [6], reduction of degree of conversion [7] may be achieved by a light modulation at the start of the light curing process (LCP). This process developed R. De Santis et al. [8] was called as the soft light energy release SLER®. It allows improved mechanical properties of dental restorative materials. Therefore, the photopolymerization process initiated by the soft light energy release photo-polymerization leads to reduction of about 20% the shrinkage rate and to increasing the strength of fast specimens. As a result, a more relaxed and homogeneous internal stress distribution also was observed [8].

Moreover, the chain growth and crosslinking also lead to an increase of elastic modulus [9,10]. During polymerization, there is a stage in monomer conversion referred to as an insoluble network formed within the resin phase. At this point, the elastic modulus of the composite has increased substantially, and the composite’s elastic limit has reached a level that does not allow enough plastic deformation to compensate for the reduction in volume. Beyond this stage, additional contraction may generate significant stress with the composite. If composite is bonded to cavity walls, shrinkage forces will occur, resulting in stresses on the bond between composite and restorated structure [11].

The main task of restorative adhesives is to provide a proper joint between composite fillings or composite cements and a surface of cavity walls. A good adhesive should not only withstand the mechanical forces, and in particular the shrinkage stresses of the cladding composite, but also prevent leakage along the edges of the restoration. The purpose of this article is to gather information on the properties of the chemical components that commonly make up modern adhesives [12,13].

In order to recreate the damaged material while ensuring tightness, avoid dimensional mismatches of the filling. Perfect adaptation should be achieved during set-up and also maintained during the thermal and mechanical operating cycle. From the outset, the dimensional stability of the filler material is compromised by the polymerization of the polymer matrix phase. The conversion of the monomer into a polymer network results in a closer packing of the molecules, which leads to bulk contraction [1,14]. The decrease of volume is usually marked as curing contraction or polymerization shrinkage. If the initial viscosity of material is lower, than the more monomer entities must be connected into polymer chains and networks. Although the space occupied by the filler particles does not participate in the curing shrinkage, high filler loading required monomers of low molar mass [15].

The too high shrinkage value is a main reason of use of multifunctional methacrylate monomers in UV-curable reconstructive compositions. These monomers, acting as photoreactive crosslinkers, are still main components of restorative fillings. It is well known that shrinkage is a major disadvantage of free radical photopolymerization and also influences the marginal integrity of the photo-curable system [16–20]. There are several ways to reduce shrinkage, for example, including monomer development (such as high mol weight dimethacrylates), reduced functionality of resins and novel polymerization methods (ring opening, step-growth, etc.).

Therefore, an application of suitable multifunctional alkoxylated monomers characterizing by low shrinkage may resolve this problem.

This paper is focused on the study of an influence of ethoxylated and propoxylated trifunctional acrylates on polymerization shrinkage of adhesive restorative materials containing hydroxylapatite and radical photoinitiator.

## 2. Materials and Methods

## 2.1. Raw Materials

Filler hydroxylapatite available from Continental Chemical (Fort Lauderdale, FL, USA) and radical photoinitiator Omnirad 127 (2-hydroxy-1-{4-[4-(2-hydroxy-2-methyl-propionyl)-benzyl]-phenyl}-2- methyl-propan-1-one) purchased from IGM Resins are presented in Table 1.

Table 1. The structures of filler hydroxylapatite and photoinitiator.

<table><tr><td>Raw Material</td><td>Chemical Structure</td><td>Chemical Name</td></tr><tr><td>Hydroxylapatite</td><td> $Ca_{5}(PO_{4})_{3}(OH)$  $Ca_{5}(PO_{4})_{3}(OH)$ </td><td>mineral form of calcium apatite</td></tr><tr><td>Omnirad 127</td><td><img src="images/page_2_table_image_3_1.jpg"/></td><td>2-hydroxy-1-{4-[4-(2-hydroxy-2-methyl-propionyl)-benzyl]-phenyl}-2-methyl-propan-1-one</td></tr></table>

The investigated trifunctional acrylates belong to a class of ethoxylated or propoxylated monomers. Ethoxylation and propoxylation is a synthetic method of introduction of ethoxy moieties into a molecule using ethylene oxide. This reaction occurs at high temperature and pressure in presence catalyst promotion of the reaction. Starting with common base molecule trimethylolpropane triacrylate (TMPTA) and variations including three-mol propoxylated acrylate $(\mathrm{TMP}(\mathrm{PO})_3\mathrm{TA})$ and three-, six- and nine-mol ethoxylated acrylates are compared (Table 2).

Table 2. Trifunctional alkoxylated acrylates investigated in this study.

<table><tr><td>Monomer</td><td>Chemical Structure</td><td>Producer</td><td>MW [Dalton]</td></tr><tr><td>Miramer M300</td><td>TMPTA (Mw=296)</td><td>Rahn USA (Aurora, IL)</td><td>296</td></tr><tr><td>Miramer M360</td><td><img src="images/page_2_table_image_6_1.jpg"/></td><td>Rahn USA (Aurora, IL)</td><td>470</td></tr><tr><td>Miramer M3130</td><td><img src="images/page_2_table_image_6_2.jpg"/></td><td>Rahn USA (Aurora, IL)</td><td>428</td></tr><tr><td>Miramer M3190</td><td><img src="images/page_2_table_image_6_3.jpg"/></td><td>Rahn USA (Aurora, IL)</td><td>692</td></tr></table>

## 2.2. Preparing of Tested Restorative Compositions

The investigated restorative compositions, containing between 38 and 78 wt.% of hydroxylapatite, 20 to 60 wt.% of tested ethoxylated or propoxylated trifunctional acrylates and 2 wt.% of photoinitiator Ominirad 127, were coated with coat weight of 90 $\mathrm{g/m^{2}}$ on silicon paper and 3 min UV cured using special UV-LED curing system from Hamamatsu Photonics K.K. (Hamamatsu, Shizuoka, Japan).

## 2.3. Shrinkage Measurement

The shrinkage measurement was conducted according to specification ASTM D 2732. The resulted polymer layers were cut in size of 1 cm × 1 cm and 3 min UV cured using UV-LED curing equipment LC-L1V3 (Hamamatsu). The parameters of two UV-LED curing systems are presented in Table 3.

Table 3. Important parameters of UV-LED curing systems applied in this work.

| Parameter | High Power Type 365 nm | High Power Type 385 nm |
| --- | --- | --- |
| UV irradiation intensity | 10,500 mW/cm<sup>2</sup> | 15,000 mW/cm<sup>2</sup> |
| Peak wavelength | 365 ± 5 | 385 ± 5 |

Dimensional changes in the restorative materials composed using EO/PO trifunctional acrylates were measured and compared after UV irradiation to the reference composition containing TMPTA. The differences in the dimensions (shrinkage S) of the irradiated samples were calculated using Equation (1):

$$
\mathrm{S}[\%] = \frac{100 \cdot (\mathrm{A}_0 - \mathrm{A})}{\mathrm{A}_0}\tag{1}
$$

where $\mathrm{A}_{0}$ is the initial and A is the final area of the sample after irradiation.

## 3. Results

## Shrinkage Evaluation as a Function of Alkoxylated Diacrylates Kind and Amount

To evaluate and compare the shrinkage run of base monomer TMPTA (trimethylolpropane triacrylate) with other trifunctional alkoxylated acrylate monomers— $-\mathrm{TMP}(\mathrm{PO})_3\mathrm{TA},\mathrm{TMP}(\mathrm{EO})_3\mathrm{TA}$ $\mathrm{TMP(EO)_6TA}$ and TMP(EO)9<sup>TA</sup> listed in Table 2—during 3 min UV-initiated curing at 365 nm by UV power of $10,500\mathrm{mW/cm^{2}}$ and at 385 nm by UV power of 15,000 mW/cm<sup>2</sup>the investigated dental compositions, containing between 38 and 78 wt.% of hydroxylapatite, 20, 30, 40, 50 and 60 wt.% of tested TMPTA, and ethoxylated or propoxylated trifunctional acrylates and 2 wt.% of photoinitiator Omnirad 127, were tested on shrinkage as a function of concentration of trifunctional acrylates studied. Figures 1–5 present the shrinkage values for tested photoreactive acrylate monomers by using of UV-LED with two wavelengths (365 nm and 385 nm) and two UV intensities (10,500 mW/cm² and $15,000\mathrm{mW/cm^{2}}$

The total polymerization shrinkage of restorative materials comprising investigated trifunctional acrylates shows Figure 6.

Moreover, in Table 4 are present parameters of tested restorative compositions, as well as the maximal values of shrinkage after photocuring.

The relationship between the concentration of double bonds and shrinkage is shown Figure 7 (Table 4).

![](images/page_4_chart_2.jpg)

Figure 1. Shrinkage of UV cured restorative composition versus TMPTA concentration and UV intensity.

![](images/page_4_chart_4.jpg)

Figure 2. Shrinkage of UV cured restorative composition versus $\mathrm{TMP(PO)_3TA}$ concentration and UV intensity.

![](images/page_4_chart_6.jpg)

Figure 3. Shrinkage of UV cured restorative composition versus TMP(EO)₃TA concentration and UV intensity.

![](images/page_5_chart_2.jpg)

Figure 4. Shrinkage of UV cured restorative composition versus $\mathrm{TMP(EO)_6TA}$ concentration and UV intensity.

![](images/page_5_chart_4.jpg)

Figure 5. Shrinkage of UV cured restorative composition versus TMP(EO)9TA concentration and UV intensity.

![](images/page_5_chart_6.jpg)

Figure 6. Total shrinkage of UV cured restorative materials containing investigated monomers.

Table 4. Monomers parameters and shrinkage of tested restorative compositions.

| Monomer | Functionality | Molecular Weight [kg/kmol] | Density at 25 °C [kg/m3] | Concentration of Double Bonds Cdb [mol/L] | Maximal Shrinkage after UV Curing [%] |
| --- | --- | --- | --- | --- | --- |
| TMPTA | 3 | 296 | 1060 | 7.2 | 12.6 |
| TMP(PO)3TA | 3 | 470 | 1070 | 4.6 | 7.9 |
| TMP(EO)3TA | 3 | 428 | 1090 | 5.1 | 9.1 |
| TMP(PO)6TA | 3 | 560 | 1100 | 3.9 | 6.0 |
| TMP(PO)9TA | 3 | 692 | 1110 | 3.2 | 2.9 |

![](images/page_6_chart_4.jpg)

Figure 7. Shrinkage of dental composition versus concentration of double bonds.

## 4. Discussion

As illustrated in Figures 1–5, the polymerization shrinkage of restorative matrix compositions containing trifunctional TMPTA and trifunctional propoxylated or ethoxylated acrylic monomers based on TMPTA increases with increasing concentration of mentioned trifunctional acrylates and increasing of UV radiation intensity. The changing degree of ethoxylation (TMPTA, $\mathrm{TMP(PO)_3TA}$ $\mathrm{TMP(EO)_3TA}$ $\mathrm{TMP(EO)_6TA}$ and $\mathrm{TMP(EO)_9TA)}$ is a convenient way to change the length of the chains of monomers as the lengths between the double bonds in the monomers. The used various diacrylates based on TMPTA with various numbers of ethoxy group with tri $(\mathrm{TMP}(\mathrm{EO})_3\mathrm{TA})$ , six $(\mathrm{TMP}(\mathrm{EO})_6\mathrm{TA})$ and nine $(\mathrm{TMP(EO)_9TA})$ mol of ethoxy groups to prediction the effect of monomer chain lengths on polymerization shrinkage shows in Figure 6 that when the degree of ethoxylation is raised, the shrinkage obviously decreases. This effect was observed for two used UV intensities.

The concentration of double bonds $(C_{db})$ is other important factor, that should be taken into consideration, and is defined as $C_{db}$ (Equation (2)).

$$
C _ {\mathrm{db}} [ \mathrm{mol/L} ] = \text {Functionality} \times \text {Monomer density / Molecular weight}\tag{2}
$$

where L is monomer chain length.

According to this equation, an increase of degree of ethoxylation leads to decrease of concentration of double bonds due to the significant increase of molecular weight. Therefore, conversion of double bonds and their concentration influence the shrinkage. Because the increase of monomer chain lengths has a more significant effect on decreasing the concentration of double bonds than on increasing conversion, shrinkage is low even at high conversion. It was also observed that the maximum shrinkage decrease was from 12.6% (ethoxylation grade 0) to 2.9% (ethoxylation grade 9), with increase the degree of ethoxylation in Table 4. Based on this, one can conclude that the monomer chain lengths effect shrinkage that is attributed to the change of the concentration of double bonds.

In addition, the reduction in the concentration of double bonds while decreasing the degree of ethoxylation causes a decrease in heat expansion. Thus, as shown in Table 4, the maximum shrinkage level moved from the expansion stage to the shrinkage stage when the degree of ethoxylation was increased. The mobility of free radicals and monomeric and pendant double bonds increases due to the formation of less strongly crosslinked networks, and the segmental diffusivity of pendant double bonds increases due to the more flexible pendant double bonds. The ethoxylation is a simple method of reducing shrinkage, because the concentration of double bonds drops significantly with increasing molecular weight of ethoxylated monomers. It was also found that the concentration of double bonds in investigated acrylate monomers influences the shrinkage of dental composition (Figure 7). It is well known that reduced functionality results in reduced shrinkage. However, it should be noted that the effect of functionality on shrinkage is very complex, because changing the functionality is always accompanied by changing both the molecular weight and the density.

## 5. Conclusions

The polymerization shrinkage of propoxylated, especially ethoxylated acrylates, depends above all on the ethoxylation grade, concentration of double bonds and UV-light intensity. Increase of chain length of monomers by higher number of ethoxy group significantly decreases the shrinkage since the obvious higher molecular weight decreases the concentration of double bonds. It is a simple way to reduce the final shrinkage. The relative concentration of double bonds also influences on both shrinkage course and shrinkage values. It was found that shrinkage decreases with the lower concentration of double bonds.

**Author Contributions:** Conceptualization, Z.C. and J.K.; methodology, C.Z. and M.B.; software, M.B. and K.M.; validation, Z.C., M.B. and D.K.; formal analysis, J.K.; investigation, M.B. and K.M.; resources, C.Z. and J.K.; data curation, M.B.; writing—original draft preparation, C.Z.; writing—review and editing, J.K.; visualization, J.K.; supervision, D.K. All authors have read and agreed to the published version of the manuscript.

**Funding:** This research received no external funding.

**Conflicts of Interest:** The authors declare no conflict of interest.

## References

1. Giachetti, L.; Russo, D.; Bambi, C.; Grandini, R. A review of polymerization shrinkage stress: Current techniques for posterior direct resin restorations. J. Contemp. Dent. Pract 2006, 7, 79–88. [[CrossRef](http://dx.doi.org/10.5005/jcdp-7-4-79)] [[PubMed](http://www.ncbi.nlm.nih.gov/pubmed/16957794)]

2. De Santis, R.; Russo, T.; Gloria, A. An analysis on the potential of diode-pumped solid-state lasers for dental materials. Mater. Sci. Eng. C 2018, 92, 862–867. [[CrossRef](http://dx.doi.org/10.1016/j.msec.2018.07.051)] [[PubMed](http://www.ncbi.nlm.nih.gov/pubmed/30184815)]

3. Bowen, R.L. Adhesive bonding of various materials to hard tissues. VI. Forces developing in direct-filling materials during hardening. J. Am. Dent. Assoc. 1967, 74, 439–445. [[CrossRef](http://dx.doi.org/10.14219/jada.archive.1967.0078)] [[PubMed](http://www.ncbi.nlm.nih.gov/pubmed/5225790)]

4. Moszner, N.; Salz, U. New developments of polymeric dental composites. Prog. Polym. Sci. 2001, 26, 535–576. [[CrossRef](http://dx.doi.org/10.1016/S0079-6700%2801%2900005-3)]

5. Labella, R.; Lambrechts, P.; van Meerbeek, B.; Vanherle, G. Polymerization shrinkage and elasticity of flowable composites and filled adhesives. Dent. Mater. 1999, 15, 128–137. [[CrossRef](http://dx.doi.org/10.1016/S0109-5641%2899%2900022-6)]

6. Lim, B.-S.; Ferracane, J.L.; Sakaguchi, R.L.; Condon, J.R. Reduction of polymerization contraction stress for dental composites by two-step light-activation. Dent. Mater. 2002, 18, 436–444. [[CrossRef](http://dx.doi.org/10.1016/S0109-5641%2801%2900066-5)]

7. Lu, H.; Stansbury, J.W.; Bowman, C.N. Impact of curing protocol on conversion and shrinkage stress. J. Dent. Res. 2005, 84, 822–826. [[CrossRef](http://dx.doi.org/10.1177/154405910508400908)] [[PubMed](http://www.ncbi.nlm.nih.gov/pubmed/16109991)]

8. De Santis, R.; Gloriaa, A.; Prisco, D.; Amendola, E.; Puppulin, L.; Pezzotti, G.; Rengo, S.; Ambrosio, L.; Nicolais, L. Fast curing of restorative materials through the soft light energy release. Dent. Mater. 2010, 26, 891–900. [[CrossRef](http://dx.doi.org/10.1016/j.dental.2010.05.004)] [[PubMed](http://www.ncbi.nlm.nih.gov/pubmed/20554315)]

9. Dauvillier, B.S.; Feilzer, A.J.; de Gee, A.J.; Davidson, C.L. Viscoelastic parameters of dental restorative materials during setting. J. Dent. Res. 2000, 79, 818–823. [[CrossRef](http://dx.doi.org/10.1177/00220345000790030601)] [[PubMed](http://www.ncbi.nlm.nih.gov/pubmed/10765954)]

10. Moszner, N.; Salz, U. Recent developments of new components for dental adhesives and composites. Macromol. Mater. Eng. 2007, 292, 245–271. [[CrossRef](http://dx.doi.org/10.1002/mame.200600414)]

11. Braga, R.R.; Ferracane, J.L. Alternatives in polymerization contraction stress management. Crit. Rev. Oral Biol. Med. 2004, 15, 175–184. [[CrossRef](http://dx.doi.org/10.1177/154411130401500306)] [[PubMed](http://www.ncbi.nlm.nih.gov/pubmed/15187035)]

© 2020 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license ([http://creativecommons.org/licenses/by/4.0/](http://creativecommons.org/licenses/by/4.0/.)).